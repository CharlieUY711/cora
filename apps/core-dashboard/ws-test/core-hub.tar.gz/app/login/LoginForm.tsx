'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { translations, type Locale } from '@/lib/i18n'

export default function LoginForm() {
  const router = useRouter()
  const [locale, setLocale] = useState<Locale>('es')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const tr = translations[locale]

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      setLoading(false)
      if (authError.message.includes('Invalid login credentials')) {
        setError(tr.login_error_invalid)
      } else {
        setError(tr.login_error_generic)
      }
      return
    }

    router.push('/dashboard')
    router.refresh()
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col">

      {/* Top bar */}
      <div className="flex items-center justify-between px-8 py-5 border-b border-neutral-800/60">
        <div>
          <span className="text-sm font-bold tracking-[0.12em] text-neutral-200">CORE</span>
          <span className="ml-3 text-[10px] font-mono tracking-[0.08em] text-neutral-600 uppercase">Hub</span>
        </div>
        {/* Language switcher */}
        <div className="flex gap-1.5">
          {(['es', 'en', 'pt'] as Locale[]).map((l) => (
            <button
              key={l}
              onClick={() => setLocale(l)}
              className={[
                'text-[10px] font-mono px-2.5 py-1 rounded border transition-all',
                locale === l
                  ? 'text-[#C9A84C] border-[#7a5f2a] bg-[rgba(201,168,76,0.08)]'
                  : 'text-neutral-600 border-neutral-800 hover:text-neutral-400 hover:border-neutral-700',
              ].join(' ')}
            >
              {l.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Center */}
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="w-full max-w-[360px]">

          {/* Logo mark */}
          <div className="mb-10 text-center">
            <div className="inline-flex items-center justify-center w-10 h-10 border border-neutral-800 rounded-lg mb-6 bg-neutral-900/60">
              <span className="text-[11px] font-bold tracking-[0.1em] text-[#C9A84C]">C</span>
            </div>
            <h1 className="text-xl font-semibold tracking-tight text-neutral-100 mb-2">
              {tr.login_title}
            </h1>
            <p className="text-xs text-neutral-600 leading-relaxed">
              {tr.login_subtitle}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-3">
            <div>
              <label className="block text-[10px] font-mono tracking-[0.08em] text-neutral-600 uppercase mb-2">
                {tr.login_email}
              </label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nombre@core.lat"
                className="w-full bg-neutral-900/80 border border-neutral-800 rounded-lg px-4 py-3 text-sm text-neutral-200 placeholder-neutral-700 focus:outline-none focus:border-neutral-600 transition-colors"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono tracking-[0.08em] text-neutral-600 uppercase mb-2">
                {tr.login_password}
              </label>
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-neutral-900/80 border border-neutral-800 rounded-lg px-4 py-3 text-sm text-neutral-200 placeholder-neutral-700 focus:outline-none focus:border-neutral-600 transition-colors"
              />
            </div>

            {error && (
              <div className="bg-red-950/40 border border-red-900/50 rounded-lg px-4 py-3">
                <p className="text-xs text-red-400">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-neutral-900 border border-neutral-700 hover:border-neutral-600 text-neutral-200 hover:text-white font-medium text-sm rounded-lg px-4 py-3 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {loading ? tr.login_loading : tr.login_button}
            </button>
          </form>

        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-8 py-4 border-t border-neutral-800/60">
        <p className="text-[10px] font-mono text-neutral-700">v1.0 — 2026</p>
        <p className="text-[10px] font-mono text-neutral-700">
          {tr.login_confidential}
        </p>
        <p className="text-[10px] font-mono text-neutral-700">
          CORE — Global Supply. Regional Growth.
        </p>
      </div>
    </div>
  )
}
