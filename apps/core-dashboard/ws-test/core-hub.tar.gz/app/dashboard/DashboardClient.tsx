'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { translations, type Locale } from '@/lib/i18n'
import { portals, type Portal } from '@/lib/portals'

interface Props {
  user: { email: string; id: string }
}

function getFirstName(email: string) {
  return email.split('@')[0].split('.')[0]
}

function PortalCard({ portal, locale }: { portal: Portal; locale: Locale }) {
  const tr = translations[locale]
  const isLive = portal.status === 'live'
  const isDev = portal.status === 'dev'

  const url = isLive
    ? (portal.id === 'biblio'
        ? process.env.NEXT_PUBLIC_URL_BIBLIO
        : portal.id === 'foundation'
        ? process.env.NEXT_PUBLIC_URL_FOUNDATION
        : portal.id === 'presentaciones'
        ? process.env.NEXT_PUBLIC_URL_PRESENTACIONES
        : process.env.NEXT_PUBLIC_URL_MARKET)
    : null

  return (
    <div
      className={[
        'group relative flex flex-col bg-neutral-900/60 border rounded-xl p-6 transition-all duration-200',
        isLive
          ? 'border-neutral-800 hover:border-neutral-700 cursor-pointer hover:bg-neutral-900/80'
          : 'border-neutral-800/50 opacity-70',
      ].join(' ')}
      onClick={() => {
        if (isLive && url) window.open(url, '_blank')
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-lg border border-neutral-800 bg-neutral-900">
            <span className="text-[10px] font-mono font-bold text-[#C9A84C] tracking-wider">
              {portal.badge}
            </span>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-neutral-100 leading-tight">
              {tr[portal.nameKey as keyof typeof tr]}
            </h3>
            <span className="text-[10px] font-mono text-neutral-700">{portal.version}</span>
          </div>
        </div>

        {/* Status badge */}
        {isLive && (
          <span className="text-[9px] font-mono px-2 py-0.5 rounded border border-[#2a4a33] bg-[rgba(107,170,122,0.08)] text-[#6baa7a]">
            LIVE
          </span>
        )}
        {isDev && (
          <span className="text-[9px] font-mono px-2 py-0.5 rounded border border-neutral-800 bg-neutral-900/80 text-neutral-600">
            {tr.dashboard_wip}
          </span>
        )}
      </div>

      {/* Description */}
      <p className="text-xs text-neutral-500 leading-relaxed flex-1 mb-5">
        {tr[portal.descKey as keyof typeof tr]}
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between">
        {isLive ? (
          <span className="text-[11px] font-medium text-neutral-400 group-hover:text-[#C9A84C] transition-colors flex items-center gap-1.5">
            {tr.dashboard_access}
            <span className="transition-transform group-hover:translate-x-0.5">→</span>
          </span>
        ) : (
          <span className="text-[11px] text-neutral-700">{tr.dashboard_soon}</span>
        )}
      </div>
    </div>
  )
}

export default function DashboardClient({ user }: Props) {
  const router = useRouter()
  const [locale, setLocale] = useState<Locale>('es')
  const [loggingOut, setLoggingOut] = useState(false)

  const tr = translations[locale]

  const livePortals = portals.filter((p) => p.status === 'live')
  const devPortals = portals.filter((p) => p.status === 'dev' || p.status === 'planned')

  async function handleLogout() {
    setLoggingOut(true)
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col">

      {/* Top bar */}
      <header className="flex items-center justify-between px-8 py-5 border-b border-neutral-800/60">
        <div className="flex items-center gap-4">
          <div>
            <span className="text-sm font-bold tracking-[0.12em] text-neutral-200">CORE</span>
            <span className="ml-2.5 text-[10px] font-mono tracking-[0.08em] text-neutral-600 uppercase">Hub</span>
          </div>
          <div className="w-px h-4 bg-neutral-800" />
          <span className="text-[10px] font-mono text-neutral-600 tracking-[0.06em] uppercase">
            Biblioteca Interna
          </span>
        </div>

        <div className="flex items-center gap-4">
          {/* Language switcher */}
          <div className="flex gap-1.5">
            {(['es', 'en', 'pt'] as Locale[]).map((l) => (
              <button
                key={l}
                onClick={() => setLocale(l)}
                className={[
                  'text-[10px] font-mono px-2.5 py-1 rounded border transition-all',
                  locale === l
                    ? 'text-[#C9A84C] border-[#7a5f2a] bg-[rgba(201,168,76,0.08)]'
                    : 'text-neutral-600 border-neutral-800 hover:text-neutral-400 hover:border-neutral-700',
                ].join(' ')}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>

          <div className="w-px h-4 bg-neutral-800" />

          {/* User */}
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-[11px] text-neutral-400">{user.email}</p>
            </div>
            <button
              onClick={handleLogout}
              disabled={loggingOut}
              className="text-[10px] font-mono px-3 py-1.5 rounded border border-neutral-800 text-neutral-600 hover:text-neutral-400 hover:border-neutral-700 transition-all disabled:opacity-40"
            >
              {loggingOut ? '...' : tr.dashboard_logout}
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-12">

        {/* Welcome */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-px w-8 bg-[#C9A84C]/40" />
            <span className="text-[10px] font-mono tracking-[0.1em] text-neutral-600 uppercase">
              {tr.dashboard_version}
            </span>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-neutral-100 mb-2">
            {tr.dashboard_welcome},{' '}
            <span className="capitalize">{getFirstName(user.email)}</span>.
          </h1>
          <p className="text-sm text-neutral-500">{tr.dashboard_subtitle}</p>
        </div>

        {/* Live portals */}
        <div className="mb-10">
          <p className="text-[10px] font-mono tracking-[0.1em] text-neutral-700 uppercase mb-4">
            {tr.dashboard_section_live}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {livePortals.map((p) => (
              <PortalCard key={p.id} portal={p} locale={locale} />
            ))}
          </div>
        </div>

        {/* Dev portals */}
        {devPortals.length > 0 && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <p className="text-[10px] font-mono tracking-[0.1em] text-neutral-700 uppercase">
                {tr.dashboard_section_dev}
              </p>
              <div className="flex-1 h-px bg-neutral-800/60" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {devPortals.map((p) => (
                <PortalCard key={p.id} portal={p} locale={locale} />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="flex items-center justify-between px-8 py-4 border-t border-neutral-800/60">
        <p className="text-[10px] font-mono text-neutral-700">{tr.dashboard_version}</p>
        <p className="text-[10px] font-mono text-neutral-700">{tr.dashboard_confidential}</p>
        <p className="text-[10px] font-mono text-neutral-700">
          CORE — Global Supply. Regional Growth.
        </p>
      </footer>
    </div>
  )
}
