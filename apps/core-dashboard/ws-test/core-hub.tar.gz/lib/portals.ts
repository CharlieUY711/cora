export type PortalStatus = 'live' | 'dev' | 'planned'

export interface Portal {
  id: string
  badge: string
  nameKey: string
  descKey: string
  url: string
  status: PortalStatus
  version: string
}

export const portals: Portal[] = [
  {
    id: 'biblio',
    badge: 'BIB',
    nameKey: 'portal_biblio_name',
    descKey: 'portal_biblio_desc',
    url: process.env.NEXT_PUBLIC_URL_BIBLIO ?? 'http://localhost:3001',
    status: 'live',
    version: 'v1.0',
  },
  {
    id: 'foundation',
    badge: 'FND',
    nameKey: 'portal_foundation_name',
    descKey: 'portal_foundation_desc',
    url: process.env.NEXT_PUBLIC_URL_FOUNDATION ?? 'http://localhost:3002',
    status: 'live',
    version: 'v1.0',
  },
  {
    id: 'presentaciones',
    badge: 'DEC',
    nameKey: 'portal_presentaciones_name',
    descKey: 'portal_presentaciones_desc',
    url: process.env.NEXT_PUBLIC_URL_PRESENTACIONES ?? 'http://localhost:3003',
    status: 'live',
    version: 'v1.0',
  },
  {
    id: 'market',
    badge: 'MKT',
    nameKey: 'portal_market_name',
    descKey: 'portal_market_desc',
    url: process.env.NEXT_PUBLIC_URL_MARKET ?? 'http://localhost:3004',
    status: 'dev',
    version: 'v0.1-dev',
  },
]
