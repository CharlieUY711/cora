export const locales = ['es', 'en', 'pt'] as const
export type Locale = typeof locales[number]

export const translations = {
  es: {
    // Login
    login_title: 'Acceso Interno',
    login_subtitle: 'Portal corporativo CORE — uso exclusivo del equipo.',
    login_email: 'Correo electrónico',
    login_password: 'Contraseña',
    login_button: 'Ingresar',
    login_loading: 'Verificando...',
    login_error_invalid: 'Credenciales incorrectas. Verificá los datos.',
    login_error_generic: 'Error al iniciar sesión. Intentá nuevamente.',
    login_confidential: 'Confidencial — Uso interno',

    // Dashboard
    dashboard_welcome: 'Bienvenido',
    dashboard_subtitle: 'Seleccioná el portal al que querés acceder.',
    dashboard_logout: 'Cerrar sesión',
    dashboard_version: 'v1.0 — 2026',
    dashboard_confidential: 'Confidencial — Uso interno',
    dashboard_section_live: 'PORTALES ACTIVOS',
    dashboard_section_dev: 'EN DESARROLLO',
    dashboard_access: 'Acceder',
    dashboard_soon: 'Próximamente',
    dashboard_wip: 'En desarrollo',

    // Portal names
    portal_biblio_name: 'Biblioteca CORE',
    portal_biblio_desc: 'Documentación oficial — Arquitectura, Estrategia, Prompts y Roadmap.',
    portal_foundation_name: 'Foundation',
    portal_foundation_desc: 'Blueprint estratégico y técnico del ecosistema 2026–2035.',
    portal_presentaciones_name: 'Presentaciones',
    portal_presentaciones_desc: 'Decks corporativos, pitches y materiales de ventas.',
    portal_market_name: 'CORE Market',
    portal_market_desc: 'Plataforma de comercio B2B, B2C y D2C para Latinoamérica.',

    // Lang switcher
    lang_es: 'ES',
    lang_en: 'EN',
    lang_pt: 'PT',
  },
  en: {
    login_title: 'Internal Access',
    login_subtitle: 'CORE corporate portal — exclusive team use.',
    login_email: 'Email address',
    login_password: 'Password',
    login_button: 'Sign in',
    login_loading: 'Verifying...',
    login_error_invalid: 'Invalid credentials. Please check your details.',
    login_error_generic: 'Login error. Please try again.',
    login_confidential: 'Confidential — Internal use',

    dashboard_welcome: 'Welcome',
    dashboard_subtitle: 'Select the portal you want to access.',
    dashboard_logout: 'Sign out',
    dashboard_version: 'v1.0 — 2026',
    dashboard_confidential: 'Confidential — Internal use',
    dashboard_section_live: 'ACTIVE PORTALS',
    dashboard_section_dev: 'IN DEVELOPMENT',
    dashboard_access: 'Access',
    dashboard_soon: 'Coming soon',
    dashboard_wip: 'In development',

    portal_biblio_name: 'CORE Library',
    portal_biblio_desc: 'Official documentation — Architecture, Strategy, Prompts and Roadmap.',
    portal_foundation_name: 'Foundation',
    portal_foundation_desc: 'Strategic and technical blueprint of the ecosystem 2026–2035.',
    portal_presentaciones_name: 'Presentations',
    portal_presentaciones_desc: 'Corporate decks, pitches and sales materials.',
    portal_market_name: 'CORE Market',
    portal_market_desc: 'B2B, B2C and D2C commerce platform for Latin America.',

    lang_es: 'ES',
    lang_en: 'EN',
    lang_pt: 'PT',
  },
  pt: {
    login_title: 'Acesso Interno',
    login_subtitle: 'Portal corporativo CORE — uso exclusivo da equipe.',
    login_email: 'Endereço de e-mail',
    login_password: 'Senha',
    login_button: 'Entrar',
    login_loading: 'Verificando...',
    login_error_invalid: 'Credenciais incorretas. Verifique os dados.',
    login_error_generic: 'Erro ao fazer login. Tente novamente.',
    login_confidential: 'Confidencial — Uso interno',

    dashboard_welcome: 'Bem-vindo',
    dashboard_subtitle: 'Selecione o portal que deseja acessar.',
    dashboard_logout: 'Sair',
    dashboard_version: 'v1.0 — 2026',
    dashboard_confidential: 'Confidencial — Uso interno',
    dashboard_section_live: 'PORTAIS ATIVOS',
    dashboard_section_dev: 'EM DESENVOLVIMENTO',
    dashboard_access: 'Acessar',
    dashboard_soon: 'Em breve',
    dashboard_wip: 'Em desenvolvimento',

    portal_biblio_name: 'Biblioteca CORE',
    portal_biblio_desc: 'Documentação oficial — Arquitetura, Estratégia, Prompts e Roadmap.',
    portal_foundation_name: 'Foundation',
    portal_foundation_desc: 'Blueprint estratégico e técnico do ecossistema 2026–2035.',
    portal_presentaciones_name: 'Apresentações',
    portal_presentaciones_desc: 'Decks corporativos, pitches e materiais de vendas.',
    portal_market_name: 'CORE Market',
    portal_market_desc: 'Plataforma de comércio B2B, B2C e D2C para a América Latina.',

    lang_es: 'ES',
    lang_en: 'EN',
    lang_pt: 'PT',
  },
} satisfies Record<Locale, Record<string, string>>

export function t(locale: Locale, key: keyof typeof translations['es']): string {
  return translations[locale][key] ?? translations['es'][key] ?? key
}
