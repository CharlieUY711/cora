import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      // ── Brand colors ──────────────────────────────────────────────────────
      colors: {
        core: {
          bg:      "#090c10",   // near-black base
          surface: "#0d1320",   // elevated surface
          border:  "#1a2333",   // subtle borders
          accent:  "#4af0ff",   // electric cyan — primary accent
          blue:    "#2a7fff",   // secondary accent
          muted:   "#3d5a7a",   // muted blue
          text: {
            DEFAULT: "#ffffff",
            secondary: "rgba(255,255,255,0.5)",
            muted:     "rgba(255,255,255,0.25)",
          },
        },
      },

      // ── Typography ────────────────────────────────────────────────────────
      fontFamily: {
        serif:  ["DM Serif Display", "Georgia", "serif"],
        sans:   ["DM Sans", "system-ui", "sans-serif"],
        mono:   ["DM Mono", "monospace"],
      },

      // ── Font sizes ────────────────────────────────────────────────────────
      fontSize: {
        "2xs": ["0.625rem", { lineHeight: "1rem" }],
      },

      // ── Animations ────────────────────────────────────────────────────────
      animation: {
        "spin-slow":     "spin 40s linear infinite",
        "spin-medium":   "spin 25s linear infinite reverse",
        "pulse-slow":    "pulse-slow 3s ease-in-out infinite",
        "fade-up":       "fade-up 0.6s ease-out both",
      },
      keyframes: {
        "pulse-slow": {
          "0%, 100%": { opacity: "0.6" },
          "50%":      { opacity: "1" },
        },
        "fade-up": {
          from: { opacity: "0", transform: "translateY(20px)" },
          to:   { opacity: "1", transform: "translateY(0)" },
        },
      },

      // ── Background patterns ───────────────────────────────────────────────
      backgroundImage: {
        "grid-cyan": `
          linear-gradient(to right, rgba(74,240,255,0.07) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(74,240,255,0.07) 1px, transparent 1px)
        `,
        "dots-cyan": `
          radial-gradient(circle, rgba(74,240,255,0.15) 1px, transparent 1px)
        `,
        "gradient-accent": "linear-gradient(135deg, #4af0ff 0%, #2a7fff 100%)",
        "gradient-dark":   "linear-gradient(180deg, #090c10 0%, #0d1a2a 100%)",
      },
      backgroundSize: {
        grid: "72px 72px",
        dots: "48px 48px",
      },

      // ── Border radius ─────────────────────────────────────────────────────
      borderRadius: {
        "3xl": "1.5rem",
        "4xl": "2rem",
      },

      // ── Box shadow ────────────────────────────────────────────────────────
      boxShadow: {
        "glow-cyan":  "0 0 40px rgba(74,240,255,0.12)",
        "glow-blue":  "0 0 40px rgba(42,127,255,0.12)",
        "card":       "0 1px 1px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.04)",
      },
    },
  },
  plugins: [],
};

export default config;
