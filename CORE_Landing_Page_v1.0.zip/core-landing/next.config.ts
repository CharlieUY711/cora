import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Monorepo path: apps/core-landing
  // basePath: '/core-landing', // uncomment if served at a subpath in the monorepo

  // Strict mode for React
  reactStrictMode: true,

  // Fonts are self-served via Google Fonts link in layout.tsx.
  // If you later move to next/font, add: experimental: { optimizeFonts: true }
};

export default nextConfig;
