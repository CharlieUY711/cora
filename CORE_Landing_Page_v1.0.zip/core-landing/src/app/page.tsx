"use client";

import React, { useState, useEffect, useRef } from "react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Module {
  id: string;
  name: string;
  tagline: string;
  description: string;
  icon: string;
}

interface IntelligenceStat {
  value: string;
  label: string;
  sub: string;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const MODULES: Module[] = [
  {
    id: "connect",
    name: "CORE Connect",
    tagline: "Acceso seguro a proveedores globales.",
    description: "Sourcing, verificación, trazabilidad.",
    icon: "⬡",
  },
  {
    id: "move",
    name: "CORE Move",
    tagline: "Logística inteligente local, regional e internacional.",
    description: "Depósitos, aduanas, distribución.",
    icon: "⬡",
  },
  {
    id: "grow",
    name: "CORE Grow",
    tagline: "Representación comercial y desarrollo de mercados.",
    description: "Canales, distribuidores, trade marketing.",
    icon: "⬡",
  },
  {
    id: "market",
    name: "CORE Market",
    tagline: "Marketplace B2B regional.",
    description: "Compradores, vendedores, transacciones.",
    icon: "⬡",
  },
];

const INTELLIGENCE_STATS: IntelligenceStat[] = [
  { value: "Demanda", label: "Predicción", sub: "Modelos de forecast por categoría y región" },
  { value: "Performance", label: "Análisis", sub: "KPIs en tiempo real de tu cadena" },
  { value: "Predicciones", label: "IA aplicada", sub: "Alertas tempranas, optimización de stock" },
  { value: "Insights", label: "Inteligencia", sub: "Reportes accionables para decisiones rápidas" },
];

const MAP_FEATURES = [
  "Orígenes principales",
  "Distribución Cono Sur",
  "Mercados de expansión",
  "Direct Shipments",
];

// ─── Utility components ───────────────────────────────────────────────────────

const GridOverlay: React.FC = () => (
  <div
    className="pointer-events-none absolute inset-0 opacity-[0.035]"
    style={{
      backgroundImage: `
        linear-gradient(to right, #4af0ff 1px, transparent 1px),
        linear-gradient(to bottom, #4af0ff 1px, transparent 1px)
      `,
      backgroundSize: "72px 72px",
    }}
  />
);

const GradientOrb: React.FC<{ className?: string }> = ({ className = "" }) => (
  <div
    className={`pointer-events-none absolute rounded-full blur-[120px] opacity-20 ${className}`}
  />
);

// ─── Navigation ───────────────────────────────────────────────────────────────

const Nav: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#090c10]/90 backdrop-blur-xl border-b border-white/5"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-3 group">
          <span
            className="text-xl font-bold tracking-[0.25em] text-white"
            style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
          >
            CORE
          </span>
          <span className="h-px w-6 bg-[#4af0ff] opacity-60 group-hover:w-10 transition-all duration-300" />
        </a>

        {/* Links */}
        <div className="hidden md:flex items-center gap-8">
          {["Soluciones", "Mercados", "Plataforma", "Empresa"].map((item) => (
            <a
              key={item}
              href="#"
              className="text-sm text-white/50 hover:text-white transition-colors duration-200 tracking-wide"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {item}
            </a>
          ))}
        </div>

        {/* CTA */}
        <a
          href="#"
          className="hidden md:inline-flex items-center gap-2 px-4 py-2 text-sm border border-white/10 text-white/70 hover:text-white hover:border-white/30 rounded-full transition-all duration-200"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          Contactar
          <span className="text-[#4af0ff]">→</span>
        </a>
      </div>
    </nav>
  );
};

// ─── Personalization Bar ──────────────────────────────────────────────────────

const PersonalizationBar: React.FC = () => {
  const [time, setTime] = useState("");
  const [lang, setLang] = useState("ES");
  const [currency, setCurrency] = useState("USD");

  useEffect(() => {
    const update = () => {
      setTime(
        new Date().toLocaleTimeString("es-UY", {
          timeZone: "America/Montevideo",
          hour: "2-digit",
          minute: "2-digit",
        })
      );
    };
    update();
    const t = setInterval(update, 10000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="sticky top-16 z-40 bg-[#090c10]/70 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-10 flex items-center gap-6 overflow-x-auto scrollbar-none">
        {/* Location */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-[#4af0ff] animate-pulse" />
          <span
            className="text-xs text-white/40"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            Uruguay
          </span>
        </div>

        <div className="w-px h-3 bg-white/10" />

        {/* Time */}
        <span
          className="text-xs text-white/30 tabular-nums shrink-0"
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          {time || "--:--"} UYT
        </span>

        <div className="w-px h-3 bg-white/10" />

        {/* Language */}
        <div className="flex items-center gap-1 shrink-0">
          {["ES", "PT", "EN"].map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`text-xs px-2 py-0.5 rounded transition-all duration-150 ${
                lang === l
                  ? "text-[#4af0ff] bg-[#4af0ff]/10"
                  : "text-white/30 hover:text-white/60"
              }`}
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              {l}
            </button>
          ))}
        </div>

        <div className="w-px h-3 bg-white/10" />

        {/* Currency */}
        <div className="flex items-center gap-1 shrink-0">
          {["USD", "EUR", "UYU", "BRL"].map((c) => (
            <button
              key={c}
              onClick={() => setCurrency(c)}
              className={`text-xs px-2 py-0.5 rounded transition-all duration-150 ${
                currency === c
                  ? "text-[#4af0ff] bg-[#4af0ff]/10"
                  : "text-white/30 hover:text-white/60"
              }`}
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Hero ─────────────────────────────────────────────────────────────────────

const Hero: React.FC = () => {
  return (
    <section
      id="hero"
      className="relative min-h-[100svh] flex flex-col items-center justify-center overflow-hidden pt-16"
    >
      {/* Background effects */}
      <GridOverlay />
      <GradientOrb className="w-[700px] h-[700px] bg-[#0d4f80] -top-40 -right-40" />
      <GradientOrb className="w-[500px] h-[500px] bg-[#0a2f50] -bottom-20 -left-20" />

      {/* Radial spotlight */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% 40%, rgba(74,240,255,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Copy */}
          <div className="flex flex-col gap-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 self-start">
              <span className="h-px w-8 bg-[#4af0ff]" />
              <span
                className="text-xs tracking-[0.2em] text-[#4af0ff] uppercase"
                style={{ fontFamily: "'DM Mono', monospace" }}
              >
                Supply Chain Intelligence
              </span>
            </div>

            {/* Headline */}
            <h1
              className="text-5xl lg:text-7xl font-normal leading-[1.05] text-white"
              style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
            >
              Global Supply.
              <br />
              <em className="not-italic text-transparent bg-clip-text"
                style={{ backgroundImage: "linear-gradient(135deg, #4af0ff 0%, #2a7fff 100%)" }}
              >
                Regional Growth.
              </em>
            </h1>

            {/* Subtitle */}
            <p
              className="text-lg text-white/50 leading-relaxed max-w-md"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              CORE conecta cadenas de suministro globales con oportunidades regionales.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-3 pt-2">
              <a
                href="#modules"
                className="group inline-flex items-center gap-3 px-6 py-3.5 bg-[#4af0ff] text-[#090c10] font-semibold text-sm rounded-full hover:bg-white transition-all duration-300"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                Explorar soluciones
                <span className="group-hover:translate-x-1 transition-transform duration-200">→</span>
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-3 px-6 py-3.5 border border-white/10 text-white/70 text-sm rounded-full hover:border-white/30 hover:text-white transition-all duration-300"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                Hablar con un especialista
              </a>
            </div>

            {/* Metrics row */}
            <div className="flex gap-8 pt-4 border-t border-white/5">
              {[
                { n: "4", label: "Módulos integrados" },
                { n: "6+", label: "Mercados activos" },
                { n: "24/7", label: "Monitoreo de cadena" },
              ].map(({ n, label }) => (
                <div key={label} className="flex flex-col gap-1">
                  <span
                    className="text-2xl font-bold text-white"
                    style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                  >
                    {n}
                  </span>
                  <span
                    className="text-xs text-white/30"
                    style={{ fontFamily: "'DM Sans', sans-serif" }}
                  >
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Globe placeholder */}
          <div className="relative hidden lg:flex items-center justify-center">
            {/*
              ─── GLOBE INTEGRATION POINT ───────────────────────────────────────
              Replace this div with your interactive globe component.
              Recommended: react-globe.gl, Three.js + globe.gl, or Cesium.js
              The globe should show:
                - animated arcs from Asia/Europe → Uruguay → Cono Sur
                - pulsing dots on major supply chain nodes
                - dark theme matching this palette (#090c10 bg, #4af0ff accent)
              Example:
                import Globe from 'react-globe.gl';
                <Globe
                  backgroundColor="rgba(0,0,0,0)"
                  globeImageUrl="//unpkg.com/three-globe/example/img/earth-night.jpg"
                  arcsData={arcsData}
                  ...
                />
              ─────────────────────────────────────────────────────────────────
            */}
            <div className="relative w-[480px] h-[480px]">
              {/* Outer ring */}
              <div className="absolute inset-0 rounded-full border border-[#4af0ff]/10 animate-[spin_40s_linear_infinite]">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-[#4af0ff]" />
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-1.5 h-1.5 rounded-full bg-white/20" />
              </div>

              {/* Middle ring */}
              <div className="absolute inset-8 rounded-full border border-white/5 animate-[spin_25s_linear_infinite_reverse]">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-white/30" />
                <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-[#4af0ff]/60" />
              </div>

              {/* Inner sphere */}
              <div className="absolute inset-16 rounded-full bg-gradient-to-br from-[#0d2a4a] via-[#090c10] to-[#051525] border border-[#4af0ff]/15 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-[#4af0ff]/40 text-xs tracking-widest mb-1" style={{ fontFamily: "'DM Mono', monospace" }}>CORE</div>
                  <div className="text-white/20 text-xs" style={{ fontFamily: "'DM Sans', sans-serif" }}>Globe placeholder</div>
                </div>

                {/* Grid lines overlay inside sphere */}
                <div
                  className="absolute inset-0 rounded-full opacity-10"
                  style={{
                    backgroundImage: `
                      repeating-linear-gradient(0deg, transparent, transparent 28px, #4af0ff 28px, #4af0ff 29px),
                      repeating-linear-gradient(90deg, transparent, transparent 28px, #4af0ff 28px, #4af0ff 29px)
                    `,
                    maskImage: "radial-gradient(circle, black 60%, transparent 100%)",
                  }}
                />
              </div>

              {/* Floating nodes */}
              {[
                { top: "12%", left: "18%", label: "Shanghai" },
                { top: "30%", right: "8%", label: "Rotterdam" },
                { bottom: "22%", left: "28%", label: "Montevideo" },
              ].map(({ label, ...pos }) => (
                <div key={label} className="absolute flex items-center gap-1.5" style={pos as React.CSSProperties}>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#4af0ff] animate-pulse" />
                  <span className="text-[10px] text-white/40" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#090c10] to-transparent pointer-events-none" />
    </section>
  );
};

// ─── Value Proposition ────────────────────────────────────────────────────────

const ValueProposition: React.FC = () => (
  <section id="value" className="relative py-32 overflow-hidden">
    <GridOverlay />
    <div className="relative z-10 max-w-7xl mx-auto px-6">
      <div className="max-w-4xl mx-auto text-center">
        <span
          className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-[#4af0ff] uppercase mb-8"
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          <span className="h-px w-6 bg-[#4af0ff]" />
          Plataforma
          <span className="h-px w-6 bg-[#4af0ff]" />
        </span>
        <p
          className="text-3xl lg:text-5xl text-white/90 leading-[1.25] font-normal"
          style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
        >
          Uruguay como plataforma de acceso al Cono Sur.{" "}
          <span className="text-white/40">
            Integramos logística, representación comercial y mercados digitales para que tu negocio llegue más lejos, más rápido y con más eficiencia.
          </span>
        </p>
      </div>

      {/* Divider */}
      <div className="mt-24 grid grid-cols-3 gap-0 border border-white/5 rounded-2xl overflow-hidden">
        {[
          { icon: "◎", label: "Más lejos", desc: "Rutas globales activas" },
          { icon: "◈", label: "Más rápido", desc: "Logística optimizada" },
          { icon: "◉", label: "Más eficiente", desc: "Operaciones integradas" },
        ].map(({ icon, label, desc }, i) => (
          <div
            key={label}
            className={`p-8 flex flex-col gap-3 ${i < 2 ? "border-r border-white/5" : ""} hover:bg-white/[0.02] transition-colors duration-200`}
          >
            <span className="text-2xl text-[#4af0ff]">{icon}</span>
            <span
              className="text-white font-semibold"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {label}
            </span>
            <span
              className="text-sm text-white/30"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {desc}
            </span>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// ─── Modules ──────────────────────────────────────────────────────────────────

const ModuleCard: React.FC<{ module: Module; index: number }> = ({ module, index }) => {
  const [hovered, setHovered] = useState(false);
  const colors = ["#4af0ff", "#2a7fff", "#a78bfa", "#34d399"];
  const accent = colors[index % colors.length];

  return (
    <div
      className="relative group p-8 border border-white/5 rounded-2xl bg-white/[0.02] hover:bg-white/[0.04] transition-all duration-300 cursor-pointer overflow-hidden"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Accent bar top */}
      <div
        className="absolute top-0 left-8 right-8 h-px transition-all duration-500"
        style={{
          background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
          opacity: hovered ? 1 : 0,
        }}
      />

      {/* Index */}
      <div
        className="text-xs mb-6 tabular-nums"
        style={{ fontFamily: "'DM Mono', monospace", color: `${accent}60` }}
      >
        0{index + 1}
      </div>

      {/* Name */}
      <h3
        className="text-xl font-semibold text-white mb-3 group-hover:text-[#4af0ff] transition-colors duration-300"
        style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
      >
        {module.name}
      </h3>

      {/* Tagline */}
      <p
        className="text-sm text-white/60 leading-relaxed mb-2"
        style={{ fontFamily: "'DM Sans', sans-serif" }}
      >
        {module.tagline}
      </p>

      {/* Description */}
      <p
        className="text-xs text-white/30"
        style={{ fontFamily: "'DM Sans', sans-serif" }}
      >
        {module.description}
      </p>

      {/* Arrow */}
      <div
        className="absolute bottom-8 right-8 text-white/20 group-hover:text-[#4af0ff] group-hover:translate-x-1 transition-all duration-300"
        style={{ fontFamily: "'DM Mono', monospace" }}
      >
        →
      </div>
    </div>
  );
};

const Modules: React.FC = () => (
  <section id="modules" className="relative py-32 overflow-hidden">
    <div
      className="pointer-events-none absolute inset-0 opacity-[0.03]"
      style={{
        backgroundImage: "radial-gradient(circle at center, #4af0ff 1px, transparent 1px)",
        backgroundSize: "48px 48px",
      }}
    />

    <div className="relative z-10 max-w-7xl mx-auto px-6">
      <div className="mb-16">
        <span
          className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-[#4af0ff] uppercase mb-4"
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          <span className="h-px w-6 bg-[#4af0ff]" />
          Módulos
        </span>
        <h2
          className="text-4xl lg:text-5xl text-white font-normal"
          style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
        >
          La plataforma completa.
        </h2>
        <p
          className="text-white/40 text-lg mt-3 max-w-xl"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          Cuatro módulos integrados que cubren todo el ciclo de supply chain.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {MODULES.map((mod, i) => (
          <ModuleCard key={mod.id} module={mod} index={i} />
        ))}
      </div>
    </div>
  </section>
);

// ─── Global Map ───────────────────────────────────────────────────────────────

const GlobalMap: React.FC = () => (
  <section id="map" className="relative py-32 overflow-hidden">
    <GradientOrb className="w-[600px] h-[600px] bg-[#0a2040] top-0 right-0" />

    <div className="relative z-10 max-w-7xl mx-auto px-6">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        {/* Left */}
        <div>
          <span
            className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-[#4af0ff] uppercase mb-6"
            style={{ fontFamily: "'DM Mono', monospace" }}
          >
            <span className="h-px w-6 bg-[#4af0ff]" />
            Red global
          </span>
          <h2
            className="text-4xl lg:text-5xl text-white font-normal mb-6"
            style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
          >
            Una red que conecta
            <em className="block not-italic text-transparent bg-clip-text"
              style={{ backgroundImage: "linear-gradient(135deg, #4af0ff 0%, #2a7fff 100%)" }}
            >
              el mundo entero.
            </em>
          </h2>
          <p
            className="text-white/40 text-base leading-relaxed mb-10"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            Visualizá en tiempo real los flujos de tu cadena de suministro, desde los orígenes hasta la distribución final en el Cono Sur.
          </p>

          {/* Feature list */}
          <div className="flex flex-col gap-3">
            {MAP_FEATURES.map((f, i) => (
              <div key={f} className="flex items-center gap-4 group">
                <div className="flex items-center gap-3">
                  <span
                    className="text-xs tabular-nums text-[#4af0ff]/40"
                    style={{ fontFamily: "'DM Mono', monospace" }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="h-px w-8 bg-white/10 group-hover:bg-[#4af0ff]/40 transition-colors duration-200" />
                </div>
                <span
                  className="text-white/60 text-sm group-hover:text-white transition-colors duration-200"
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  {f}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Map placeholder */}
        <div className="relative">
          {/*
            ─── MAP INTEGRATION POINT ────────────────────────────────────────
            Replace this placeholder with your interactive map component.
            Recommended libraries:
              - react-map-gl (Mapbox GL) with a dark custom style
              - Leaflet.js with dark tiles (CartoDB Dark Matter)
              - deck.gl for arc layers showing trade routes
            Map should show:
              - Animated arcs: Asia → UY, Europe → UY, UY → Cono Sur
              - Marker clusters for ports/hubs
              - Heatmap of shipment density
            ─────────────────────────────────────────────────────────────────
          */}
          <div className="relative h-[440px] rounded-2xl border border-white/5 bg-[#0a0f18] overflow-hidden">
            <GridOverlay />

            {/* Simulated map dots */}
            <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 600 440" fill="none">
              {/* Arcs */}
              <path d="M 80 120 Q 250 40 380 200" stroke="#4af0ff" strokeWidth="1" strokeDasharray="4 4" fill="none" />
              <path d="M 520 100 Q 450 160 380 200" stroke="#2a7fff" strokeWidth="1" strokeDasharray="4 4" fill="none" />
              <path d="M 380 200 Q 330 280 300 340" stroke="#4af0ff" strokeWidth="1.5" fill="none" />
              <path d="M 380 200 Q 280 280 240 320" stroke="#4af0ff" strokeWidth="1" strokeDasharray="4 4" fill="none" />
              {/* Nodes */}
              {[
                [80, 120, "Shanghai"],
                [520, 100, "Rotterdam"],
                [380, 200, "Montevideo"],
                [300, 340, "Buenos Aires"],
                [240, 320, "Santiago"],
              ].map(([x, y, label]) => (
                <g key={String(label)}>
                  <circle cx={Number(x)} cy={Number(y)} r="4" fill="#4af0ff" opacity="0.8" />
                  <circle cx={Number(x)} cy={Number(y)} r="10" fill="#4af0ff" opacity="0.1" />
                  <text x={Number(x) + 12} y={Number(y) + 4} fill="#4af0ff" fontSize="10" opacity="0.5" fontFamily="monospace">
                    {label}
                  </text>
                </g>
              ))}
            </svg>

            {/* Overlay label */}
            <div className="absolute bottom-6 left-6">
              <div className="text-xs text-white/20 mb-1" style={{ fontFamily: "'DM Mono', monospace" }}>
                Map placeholder
              </div>
              <div className="text-xs text-[#4af0ff]/40" style={{ fontFamily: "'DM Mono', monospace" }}>
                → Integrar con react-map-gl / deck.gl
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

// ─── CORE Intelligence ────────────────────────────────────────────────────────

const Intelligence: React.FC = () => (
  <section id="intelligence" className="relative py-32 overflow-hidden">
    <GridOverlay />
    <GradientOrb className="w-[500px] h-[500px] bg-[#0d2040] bottom-0 left-0" />

    <div className="relative z-10 max-w-7xl mx-auto px-6">
      <div className="text-center mb-20">
        <span
          className="inline-flex items-center gap-2 text-xs tracking-[0.2em] text-[#4af0ff] uppercase mb-4"
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          <span className="h-px w-6 bg-[#4af0ff]" />
          CORE Intelligence
        </span>
        <h2
          className="text-4xl lg:text-5xl text-white font-normal"
          style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
        >
          Datos que impulsan decisiones.
        </h2>
        <p
          className="text-white/40 text-lg mt-3 max-w-2xl mx-auto"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          Análisis, predicciones e insights accionables para optimizar cada nodo de tu cadena.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {INTELLIGENCE_STATS.map(({ value, label, sub }, i) => (
          <div
            key={value}
            className="relative p-6 border border-white/5 rounded-2xl bg-white/[0.02] hover:bg-white/[0.04] transition-all duration-300 group overflow-hidden"
          >
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
              style={{
                background: "radial-gradient(circle at 50% 0%, rgba(74,240,255,0.04) 0%, transparent 70%)",
              }}
            />
            <div
              className="text-xs text-[#4af0ff]/40 mb-4 tabular-nums"
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              /{String(i + 1).padStart(2, "0")}
            </div>
            <div
              className="text-xl font-semibold text-white mb-1"
              style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
            >
              {value}
            </div>
            <div
              className="text-sm text-[#4af0ff]/80 mb-3"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {label}
            </div>
            <p
              className="text-xs text-white/25 leading-relaxed"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {sub}
            </p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// ─── Social Proof ─────────────────────────────────────────────────────────────

const SocialProof: React.FC = () => (
  <section id="social" className="relative py-24 overflow-hidden border-y border-white/5">
    <div className="relative z-10 max-w-7xl mx-auto px-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-8">
        <div>
          <p
            className="text-white/40 text-sm uppercase tracking-widest mb-2"
            style={{ fontFamily: "'DM Mono', monospace" }}
          >
            Seguinos
          </p>
          <p
            className="text-white text-xl"
            style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
          >
            Novedades, insights y mercados.
          </p>
        </div>

        <div className="flex gap-4">
          {/* LinkedIn */}
          {/* TODO: replace href with real LinkedIn URL */}
          <a
            href="#"
            className="group flex items-center gap-3 px-5 py-3 border border-white/10 rounded-full hover:border-[#4af0ff]/40 hover:bg-[#4af0ff]/5 transition-all duration-300"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white/40 group-hover:fill-[#4af0ff] transition-colors duration-200">
              <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
            </svg>
            <span
              className="text-sm text-white/50 group-hover:text-white transition-colors duration-200"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              LinkedIn
            </span>
          </a>

          {/* Instagram */}
          {/* TODO: replace href with real Instagram URL */}
          <a
            href="#"
            className="group flex items-center gap-3 px-5 py-3 border border-white/10 rounded-full hover:border-[#4af0ff]/40 hover:bg-[#4af0ff]/5 transition-all duration-300"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white/40 group-hover:fill-[#4af0ff] transition-colors duration-200">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
            </svg>
            <span
              className="text-sm text-white/50 group-hover:text-white transition-colors duration-200"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              Instagram
            </span>
          </a>
        </div>
      </div>
    </div>
  </section>
);

// ─── Footer ───────────────────────────────────────────────────────────────────

const Footer: React.FC = () => {
  const links: Record<string, string[]> = {
    "Sobre CORE": ["Historia", "Equipo", "Inversores", "Blog"],
    Soluciones: ["CORE Connect", "CORE Move", "CORE Grow", "CORE Market"],
    Países: ["Uruguay", "Argentina", "Brasil", "Chile", "Paraguay"],
    Contacto: ["Ventas", "Soporte", "Partnership", "Prensa"],
    Legal: ["Privacidad", "Términos", "Cookies", "Compliance"],
  };

  return (
    <footer className="relative pt-20 pb-10 border-t border-white/5 overflow-hidden">
      <GridOverlay />
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Top */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-10 mb-16">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <span
              className="text-lg font-bold tracking-[0.2em] text-white block mb-3"
              style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
            >
              CORE
            </span>
            <p
              className="text-xs text-white/25 leading-relaxed"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              Global Supply.
              <br />
              Regional Growth.
            </p>
          </div>

          {/* Link columns */}
          {Object.entries(links).map(([group, items]) => (
            <div key={group}>
              <h4
                className="text-xs font-semibold text-white/60 uppercase tracking-widest mb-4"
                style={{ fontFamily: "'DM Mono', monospace" }}
              >
                {group}
              </h4>
              <ul className="flex flex-col gap-2">
                {items.map((item) => (
                  <li key={item}>
                    {/* TODO: replace href with real URLs */}
                    <a
                      href="#"
                      className="text-xs text-white/25 hover:text-white/60 transition-colors duration-200"
                      style={{ fontFamily: "'DM Sans', sans-serif" }}
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-white/5">
          <p
            className="text-xs text-white/20"
            style={{ fontFamily: "'DM Mono', monospace" }}
          >
            © {new Date().getFullYear()} CORE. All rights reserved.
          </p>
          <div className="flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-[#4af0ff] animate-pulse" />
            <span
              className="text-xs text-white/20 ml-1"
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              System operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

// ─── Landing Page (root export) ───────────────────────────────────────────────

export default function LandingPage(): React.ReactElement {
  return (
    <div className="min-h-screen bg-[#090c10] text-white antialiased">
      {/* Google Fonts — DM Serif Display + DM Sans + DM Mono */}
      {/* Add to <head> in layout.tsx:
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link
            href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap"
            rel="stylesheet"
          />
      */}
      <Nav />
      <PersonalizationBar />
      <main>
        <Hero />
        <ValueProposition />
        <Modules />
        <GlobalMap />
        <Intelligence />
        <SocialProof />
      </main>
      <Footer />
    </div>
  );
}
