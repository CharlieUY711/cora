import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CORE — Global Supply. Regional Growth.",
  description:
    "CORE conecta cadenas de suministro globales con oportunidades regionales. Logística, representación comercial y mercados digitales para el Cono Sur.",
  openGraph: {
    title: "CORE — Global Supply. Regional Growth.",
    description:
      "Conectamos cadenas de suministro globales con oportunidades regionales.",
    // TODO: add og:image at /public/og.png
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#090c10] text-white antialiased">{children}</body>
    </html>
  );
}
